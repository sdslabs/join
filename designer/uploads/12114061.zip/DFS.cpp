bool vis[MAXN];
stack<int> S;

void BFS(){
    memset(vis, false, sizeof(vis));
    S.push(0);
    vis[0] = true;
    while(!S.empty()){
        u = S.top();
        S.pop();
        for(int i = adj[u].size() - 1;i >= 0;i--){
            v = adj[u][i];
            if(vis[v] == false){
                S.push(v);
            }
        }
    }
}
