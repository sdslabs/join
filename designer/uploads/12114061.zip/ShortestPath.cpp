bool vis[MAXN];
int dis[MAXN];
set< pair<int, int> > S;

// when no of edges is less
void ShortestPath(){
    for(int i = 1;i < MAXN;i++){
        vis[i] = false;
        dis[i] = INF;
    }
    S.insert(MP(0, 0));
    vis[0] = true;
    dis[0] = 0;
    while(!Q.empty()){
        u = ( *(Q.begin()) ).S;
        Q.erase( *(Q.begin()) );
        for(int i = adj[u].size() - 1;i >= 0;i--){
            v = adj[u][i].F;
            d = adj[u][i].S;
            if(vis[v] == true){
                if(dis[v] > dis[u] + d){
                    S.erase(MP(dis[v], v));
                    dis[v] = dis[u] + d;
                    S.insert(MP(dis[v], v));
                }
            }
            else{
                dis[v] = dis[u] + d;
                S.insert(MP(dis[v], v));
            }
        }
    }
}

// when no of edges is more
void ShortestPath(){
    for(int i = 0;i < MAXN;i++){
        vis[i] = false;
        dis[i] = INF;
    }
    dis[0] = 0;
    while(true){
        d = INF;
        for(int i = 0; i < MAXN; i++){
            if(vis[i] == false){
                if(dis[i] < d){
                    d = dis[i];
                    u = i;
                }
            }
        }
        if(u == n){
            break;
        }
        for(i = adj[u].size() - 1; i >= 0; i--){
            v = adj[u][i].F;
            d = adj[u][i].S;
            if(dis[v] > dis[u] + d){
                dis[v] = dis[u] + d;
            }
        }
    }
    cout<<required ans<<endl;
}
