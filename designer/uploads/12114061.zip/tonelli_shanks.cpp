#define LL long long

inline LL PowerMod(LL base, LL power, LL mod){
    LL ret = 1;
    if(base >= mod){
        base %= mod;
    }
    while(power > 0){
        if((power & 1) == 1){
            ret *= base;
            if(ret >= mod){
                ret %= mod;
            }
        }
        power >>= 1;
        base *= base;
        if(base >= mod){
            base %= mod;
        }
    }
    return ret;
}

map<LL , int> pp;
LL p;
LL prime[] = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97,
               101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193,
               197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271 };

inline LL InvMod(LL a, LL mod){
    return PowerMod(a, mod - 2, mod);
}

inline LL Legendre(LL n){
    LL ret = PowerMod(n, (p - 1) / 2, p);
    if(ret == p - 1){
        return -1;
    }
    return ret;
}

inline LL FLQN(){
    for(int i = 0;i < 27;i++){
        if(Legendre(prime[i]) == -1){
            return prime[i];
        }
    }
}

inline LL RootMod(LL n){
    n %= p;
    if(n < 0){
        n += p;
    }
    LL l = Legendre(n);
    if(l == 1){
        LL q, s = 0;
        q = p - 1;
        while(q % 2 == 0){
            q /= 2;
            s++;
        }
        if(s == 1 && p % 4 == 3){
            return PowerMod(n, (p + 1) / 4, p);
        }
        LL z = FLQN();
        LL c = PowerMod(z, q, p);
        LL t = PowerMod(n, q, p);
        LL r = PowerMod(n, (q + 1) / 2, p);
        LL i, b = 0, tt;
        while(true){
            if(t == 1){
                return r;
            }
            tt = t;
            for(i = 0;i < s;i++){
                //cout<<i<<" "<<t<<" "<<p<<endl;
                if(t == 1){
                    break;
                }
                t = t*t;
                t %= p;
            }
            t = tt;

            b = PowerMod(c, PowerMod(2LL, s - i - 1, p), p);

            r = r * b;
            r %= p;

            b *= b;
            b %= p;

            t *= b;
            t %= p;

            c = b;

            s = i;
        }
    }
    else {
        return l;
    }
}
