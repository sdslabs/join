bool vis[MAXN];
queue<int> Q;

void BFS(){
    memset(vis, false, sizeof(vis));
    Q.push(0);
    vis[0] = true;
    while(!Q.empty()){
        u = Q.front();
        Q.pop();
        for(int i = adj[u].size() - 1;i >= 0;i--){
            v = adj[u][i];
            if(vis[v] == false){
                Q.push(v);
            }
        }
    }

}
